<?php
class CRM_Admin_Groups {

	public static function manage()
	{
		$groups = CRM_Model_Groups::get_all();
		View::load('CRM', 'admin/groups/manage',
			array('groups' => $groups));
	}

	public static function create()
	{
		if($_POST)
		{
			Validate::check('name', 'Name', array('required'));

			if(Validate::passed())
			{
				if(!CRM_Model_Groups::exists($_POST['name']))
				{
					if(CRM_Model_Groups::create($_POST['name']))
					{
						Message::store(MSG_OK, 'Group created successfully.');
						Router::redirect('admin/crm/groups');
					}
					else
						Message::set(MSG_ERR, 'Error creating group. Please try again.');
				}
				else
					Message::set(MSG_ERR, 'A group with that name already exists.');
			}
		}

		View::load('CRM', 'admin/groups/create');
	}

	public static function details($cid)
	{
		View::load('CRM', 'admin/groups/details');
	}

	public static function edit($cid)
	{
		View::load('CRM', 'admin/groups/edit');
	}

	public static function delete($cid)
	{
		if(CRM_Model_Groups::delete($cid))
			Message::store(MSG_OK, 'Group deleted successfully.');
		else
			Message::store(MSG_ERR, 'Error deleting group. Please try again.');

		Router::redirect('admin/crm/groups');
	}

}
