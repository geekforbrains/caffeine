<?php
final class CRM_Events {

	public static function path_callbacks()
	{
		return array(
			// Front
			'crm/cron' => array(
				'callback' => array('CRM', 'cron'),
				'auth' => true
			),
			'crm/subscribe' => array(
				'callback' => array('CRM', 'subscribe'),
				'auth' => true
			),
			'crm/unsubscribe/%d' => array(
				'callback' => array('CRM', 'unsubscribe'),
				'auth' => true
			),
			
			// Main tab
			'admin/crm' => array(
				'title' => CRM_TAB,
				'alias' => 'admin/crm/companies/manage'
			),

			// Companies
			'admin/crm/companies' => array(
				'title' => 'Companies',
				'alias' => 'admin/crm/companies/manage'
			),
			'admin/crm/companies/manage' => array(
				'title' => 'Manage Companies',
				'callback' => array('CRM_Admin_Companies', 'manage'),
				'auth' => 'manage companies'
			),
			'admin/crm/companies/create' => array(
				'title' => 'Create Company',
				'callback' => array('CRM_Admin_Companies', 'create'),
				'auth' => 'create companies'
			),
			'admin/crm/companies/details/%d' => array(
				'callback' => array('CRM_Admin_Companies', 'details'),
				'auth' => 'view company details',
			),
			'admin/crm/companies/edit/%d' => array(
				'callback' => array('CRM_Admin_Companies', 'edit'),
				'auth' => 'edit companies'
			),
			'admin/crm/companies/delete/%d' => array(
				'callback' => array('CRM_Admin_Companies', 'delete'),
				'auth' => 'delete companies'
			),

			// People
			'admin/crm/people' => array(
				'title' => 'People',
				'alias' => 'admin/crm/people/manage'
			),
			'admin/crm/people/manage' => array(
				'title' => 'Manage People',
				'callback' => array('CRM_Admin_People', 'manage'),
				'auth' => 'manage people'
			),
			'admin/crm/people/create' => array(
				'title' => 'Create Person',
				'callback' => array('CRM_Admin_People', 'create'),
				'auth' => 'create people'
			),
			'admin/crm/people/details/%d' => array(
				'callback' => array('CRM_Admin_People', 'details'),
				'auth' => 'view person details'
			),
			'admin/crm/people/edit/%d' => array(
				'callback' => array('CRM_Admin_People', 'edit'),
				'auth' => 'edit people'
			),
			'admin/crm/people/delete/%d' => array(
				'callback' => array('CRM_Admin_People', 'delete'),
				'auth' => 'delete people'
			),
			'admin/crm/people/details/%d/join-group' => array(
				'callback' => array('CRM_Admin_People', 'join_group'),
				'auth' => 'join groups'
			),
			'admin/crm/people/details/%d/leave-group/%d' => array(
				'callback' => array('CRM_Admin_People', 'leave_group'),
				'auth' => 'leave groups'
			),
			'admin/crm/people/import' => array(
				'title' => 'Import People',
				'callback' => array('CRM_Admin_People', 'import'),
				'auth' => 'import people'
			),

			// Groups
			'admin/crm/groups' => array(
				'title' => 'Groups',
				'alias' => 'admin/crm/groups/manage'
			),
			'admin/crm/groups/manage' => array(
				'title' => 'Manage Groups',
				'callback' => array('CRM_Admin_Groups', 'manage'),
				'auth' => 'manage groups'
			),
			'admin/crm/groups/create' => array(
				'title' => 'Create Group',
				'callback' => array('CRM_Admin_Groups', 'create'),
				'auth' => 'create groups'
			),
			'admin/crm/groups/details/%d' => array(
				'callback' => array('CRM_Admin_Groups', 'details'),
				'auth' => 'view group details'
			),
			'admin/crm/groups/edit/%d' => array(
				'callback' => array('CRM_Admin_Groups', 'edit'),
				'auth' => 'edit groups'
			),
			'admin/crm/groups/delete/%d' => array(
				'callback' => array('CRM_Admin_Groups', 'delete'),
				'auth' => 'delete groups'
			),

			// Sales
			/*
			'admin/crm/sales' => array(
				'title' => 'Sales',
				'alias' => 'admin/crm/sales/manage'
			),
			'admin/crm/sales/manage' => array(
				'title' => 'Manage Sales',
				'callback' => array('CRM_Admin_Sales', 'manage'),
				'auth' => 'manage sales'
			),
			'admin/crm/sales/create' => array(
				'title' => 'Create Sale',
				'callback' => array('CRM_Admin_Sales', 'create'),
				'auth' => 'create sale'
			),
			'admin/crm/sales/details/%d' => array(
				'callback' => array('CRM_Admin_Sales', 'details'),
				'auth' => 'view sales details'
			),
			'admin/crm/sales/edit/%d' => array(
				'callback' => array('CRM_Admin_Sales', 'edit'),
				'auth' => 'edit sales'
			),
			'admin/crm/sales/delete/%d' => array(
				'callback' => array('CRM_Admin_Sales', 'delete'),
				'auth' => 'delete sales'
			)
			*/
		);
	}

	public static function database_install()
	{
		return array(
			'crm_notes' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'related_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'note' => array(
						'type' => 'text',
						'size' => 'normal',
						'not null' => true
					)
				),

				'indexes' => array(
					'related_cid' => array('related_cid')
				),

				'primary key' => array('cid')
			),

			'crm_note_attachments' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'media_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					)
				),

				'indexes' => array(
					'media_cid' => array('media_cid')
				),

				'primary key' => array('cid')
			),

			'crm_companies' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'name' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					)
				),

				'primary key' => array('name')
			),

			'crm_people' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'company_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'email' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'first_name' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'last_name' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'address' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'city' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'province' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'postal' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'phone_home' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'phone_work' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'phone_mobile' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'twitter' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					)
				),

				'indexes' => array(
					'company_cid' => array('company_cid'),
					'email' => array('email')
				),

				'primary key' => array('cid')
			),

			'crm_groups' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'name' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					)
				),

				'primary key' => array('cid')
			),

			'crm_group_members' => array(
				'fields' => array(
					'group_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'person_cid' => array(	
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					)
				),

				'indexes' => array(
					'group_cid' => array('group_cid'),
					'person_cid' => array('person_cid')
				)
			),

			'crm_sales' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'related_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'name' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'status' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'type' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'amount' => array(
						'type' => 'double',
						'size' => 'normal',
						'not null' => true
					),
					'rate' => array(
						'type' => 'int',
						'size' => 'normal',
						'unsigned' => true,
						'not null' => true
					)
				),

				'indexes' => array(
					'related_cid' => array('related_cid'),
					'status' => array('status')
				),

				'primary key' => array('cid')
			)
		);
	}

}
