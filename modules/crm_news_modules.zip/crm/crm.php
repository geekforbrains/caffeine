<?php
/**
 * =============================================================================
 * CRM
 * @author Gavin Vickery <gdvickery@gmail.com>
 * @version 2.0
 *
 * TODO Description
 * =============================================================================
 */
class CRM {

	/**
	 * -------------------------------------------------------------------------
	 * Subscribes a person posted from a subscription form. Email is always 
	 * required. Other fields are optional.
	 * -------------------------------------------------------------------------
	 */
	public static function subscribe()
	{
		if($_POST)
		{
			if(!Validate::check('email', null, array('required')))
				Message::set(MSG_ERR, 'Email is required.');

			elseif(!Validate::check('email', null, array('valid_email')))
				Message::set(MSG_ERR, 'Invalid email address.');

			elseif(CRM_Model_People::exists($_POST['email']))
				Message::set(MSG_ERR, 'That email is already subscribed.');

			else
			{
				if($person_cid = CRM_Model_People::create($_POST))
				{
					Message::set(MSG_OK, 'Subscription successful!');

					// Check for group field, if set, add person to those groups
					if(isset($_POST['groups']))
					{
						$group_cids = explode(',', $_POST['groups']);
						foreach($group_cids as $group_cid)
						{
							$group_cid = intval(trim($group_cid));
							if(CRM_Model_Groups::get_by_cid($group_cid))
							{
								if(!CRM_Model_Groups::is_member($group_cid, $person_cid))
									CRM_Model_Groups::add_member($group_cid, $person_cid);
							}
						}
					}
				}
				else
					Message::set(MSG_ERR, 'Error subscribing. Please try again.');
			}
		}
		else
			Router::redirect('/');

		View::load('CRM', 'subscribe');
	}

}
