<?php
class CRM_Model_Groups {

	public static function get_all()
	{
		Database::query('
			SELECT
				cg.*,
				c.created,
				c.updated
			FROM {crm_groups} cg
				JOIN {content} c ON c.id = cg.cid
			WHERE
				c.site_cid = %s
			',
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function get_by_cid($cid)
	{
		Database::query('
			SELECT
				cg.*,
				c.created,
				c.updated
			FROM {crm_groups} cg
				JOIN {content} c ON c.id = cg.cid
			WHERE cg.cid = %s
				AND c.site_cid = %s
			',
			$cid,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return Database::fetch_all();
		return false;
	}

	/**
	 * -------------------------------------------------------------------------
	 * Returns all groups a member is a part of.
	 * -------------------------------------------------------------------------
	 */
	public static function get_by_member($cid)
	{
		Database::query('
			SELECT
				cg.*,
				c.created,
				c.updated
			FROM {crm_groups} cg
				JOIN {content} c ON c.id = cg.cid
				JOIN {crm_group_members} cgm ON cgm.group_cid = cg.cid
			WHERE cgm.person_cid = %s
				AND c.site_cid = %s
			',
			$cid,
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function exists($name)
	{
		Database::query('
			SELECT
				cg.cid
			FROM {crm_groups} cg
				JOIN {content} c ON c.id = cg.cid
			WHERE cg.name LIKE %s
				AND c.site_cid = %s
			',
			$name,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return true;
		return false;
	}

	public static function create($name)
	{
		$cid = Content::create(CRM_TYPE_GROUP);
		return Database::insert('crm_groups', array(
			'cid' => $cid,
			'name' => $name
		));
	}

	public static function delete($cid)
	{
		if(self::get_by_cid($cid))
		{
			Content::delete($cid);
			Database::delete('crm_group_members', array('group_cid' => $cid));
			return Database::delete('crm_groups', array('cid' => $cid));
		}

		return false;
	}

	public static function is_member($group_cid, $person_cid)
	{
		Database::query('
			SELECT
				cg.cid
			FROM {crm_groups} cg
				LEFT JOIN {crm_group_members} cgm ON cgm.group_cid = cg.cid
			WHERE cg.cid = %s
				AND cgm.person_cid = %s
			',
			$group_cid,
			$person_cid
		);

		if(Database::num_rows() > 0)
			return true;
		return false;
	}

	public static function add_member($group_cid, $person_cid)
	{
		return Database::insert('crm_group_members', array(
			'group_cid' => $group_cid,
			'person_cid' => $person_cid
		));
	}

	/**
	 * -------------------------------------------------------------------------
	 * Used to remove a member from one or all groups. If no $group_cid param
	 * is given, the user will be removed from all groups.
	 * -------------------------------------------------------------------------
	 */
	public static function remove_member($person_cid, $group_cid = null)
	{
		if(is_null($group_cid))
		{
			return Database::delete('crm_group_members', array(
				'person_cid' => $person_cid
			));
		}
		else
		{
			return Database::delete('crm_group_members', array(
				'group_cid' => $group_cid,
				'person_cid' => $person_cid
			));
		}
	}

}
