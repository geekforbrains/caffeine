<?php
class CRM_Admin_Companies {

	public static function manage()
	{
		$companies = CRM_Model_Companies::get_all();

		View::load('CRM', 'admin/companies/manage',
			array('companies' => $companies));
	}

	public static function create()
	{
		if($_POST)
		{
			Validate::check('name', 'Name', array('required'));

			if(Validate::passed())
			{
				if(!CRM_Model_Companies::exists($_POST['name']))
				{
					if(CRM_Model_Companies::create($_POST['name']))
					{
						Message::store(MSG_OK, 'Company created successfully.');
						Router::redirect('admin/crm/companies');
					}
					else
						Message::set(MSG_ERR, 'Error creating company. Please try again.');
				}
				else
					Message::set(MSG_ERR, 'A company with that name already exists.');
			}
		}

		View::load('CRM', 'admin/companies/create');
	}

	public static function details($cid)
	{
		if(!$company = CRM_Model_Companies::get_by_cid($cid))
			Router::redirect('admin/crm/companies');

		View::load('CRM', 'admin/companies/details');
	}
	
	public static function edit($cid)
	{
		if(!$company = CRM_Model_Companies::get_by_cid($cid))
			Router::redirect('admin/crm/companies');

		View::load('CRM', 'admin/companies/edit');
	}
	
	public static function delete($cid)
	{
		if(CRM_Model_Companies::delete($cid))
			Message::store(MSG_OK, 'Company deleted successfully.');
		else
			Message::store(MSG_ERR, 'Error deleting company. Please try again.');

		Router::redirect('admin/crm/companies');
	}

}
