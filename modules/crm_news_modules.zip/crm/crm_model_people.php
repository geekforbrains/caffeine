<?php
class CRM_Model_People {

	public static function get_all()
	{
		Database::query('
			SELECT 
				cp.*,
				cc.cid as company_cid,
				cc.name as company_name,
				c.created,
				c.updated
			FROM {crm_people} cp
				JOIN {content} c ON c.id = cp.cid
				LEFT JOIN {crm_companies} cc ON cc.cid = cp.company_cid
			WHERE
				c.site_cid = %s
			',
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function get_by_cid($cid)
	{
		Database::query('
			SELECT
				cp.*,
				c.created,
				c.updated
			FROM {crm_people} cp
				JOIN {content} c ON c.id = cp.cid
			WHERE cp.cid = %s
				AND c.site_cid = %s
			',
			$cid,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return Database::fetch_array();
		return false;
	}

	// Get all people of the given group
	public static function get_by_group($group_cid)
	{
		Database::query('
			SELECT
				cp.*
			FROM {crm_group_members} cgm
				LEFT JOIN {crm_people} cp ON cp.cid = cgm.person_cid
			WHERE
				cgm.group_cid = %s
			',
			$group_cid
		);
	
		return Database::fetch_all();
	}

	public static function exists($email)
	{
		Database::query('
			SELECT
				cp.*
			FROM {crm_people} cp
				JOIN {content} c ON c.id = cp.cid
			WHERE cp.email LIKE %s
				AND c.site_cid = %s
			',
			$email,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return true;
		return false;
	}

	public static function create($data)
	{
		$cid = Content::create(CRM_TYPE_PERSON);
		
		$status = Database::insert('crm_people', array(
			'cid' => $cid,
			'company_cid' => isset($data['company_cid']) ? $data['company_cid'] : 0,
			'email' => $data['email'],
			'first_name' => isset($data['first_name']) ? $data['first_name'] : null,
			'last_name' => isset($data['last_name']) ? $data['last_name'] : null,
			'address' => isset($data['address']) ? $data['address'] : null,
			'city' => isset($data['city']) ? $data['city'] : null,
			'province' => isset($data['province']) ? $data['province'] : null,
			'postal' => isset($data['postal']) ? $data['postal'] : null,
			'phone_home' => isset($data['phone_home']) ? $data['phone_home'] : null,
			'phone_work' => isset($data['phone_work']) ? $data['phone_work'] : null,
			'phone_mobile' => isset($data['phone_mobile']) ? $data['phone_mobile'] : null,
			'twitter' => isset($data['twitter']) ? $data['twitter'] : null
		));

		if($status)
			return $cid;
		return false;
	}

	public static function delete($cid)
	{
		if(self::get_by_cid($cid))
		{
			Content::delete($cid);
			
			// Delete stuff associated with person
			CRM_Model_Groups::remove_member($cid);

			return Database::delete('crm_people', array('cid' => $cid));
		}

		return false;
	}

}
