<?php
class CRM_Model_Sales {

	public static function get_all($status)
	{
		Database::query('
			SELECT
				cs.*,
				c.created,
				c.updated
			FROM {crm_sales} cs
				JOIN {content} c ON c.id = cs.cid
			WHERE cs.status = %s
				AND c.site_cid = %s
			',
			$status,
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function get_by_cid($cid)
	{
		Database::query('
			SELECT
				cs.*,
				c.created,
				c.updated
			FROM {crm_sales} cs
				JOIN {content} c ON c.id = cs.cid
			WHERE cs.cid = %s
				AND c.site_cid = %s
			',
			$cid,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return Database::fetch_array();
		return false;
	}

	public static function create($relative_cid, $name, $type, $amount, $rate)
	{
		$cid = Content::create(CRM_TYPE_SALE);
		return Database::insert('crm_sales', array(
			'cid' => $cid,
			'relative_cid' => $cid,
			'name' => $name,
			'type' => $type,
			'amount' => $amount,
			'rate' => $rate
		));
	}

}
