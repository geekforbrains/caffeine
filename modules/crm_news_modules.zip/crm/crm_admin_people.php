<?php
class CRM_Admin_People {

	public static function manage()
	{
		$people = CRM_Model_People::get_all();

		View::load('CRM', 'admin/people/manage',
			array('people' => $people));
	}

	public static function create()
	{
		if($_POST)
		{
			Validate::check('email', 'Email', array('required', 'valid_email'));
			//Validate::check('first_name', 'First Name', array('required'));
			//Validate::check('last_name', 'Last Name', array('required'));

			if(Validate::passed())
			{
				if(!CRM_Model_People::exists($_POST['email']))
				{
					if(CRM_Model_People::create($_POST))
					{
						Message::store(MSG_OK, 'Person created successfully.');
						Router::redirect('admin/crm/people');
					}
					else
						Message::set(MSG_ERR, 'Error creating person. Please try again.');
				}
				else
					Message::set(MSG_ERR, 'A person with that email already exists.');
			}
		}

		$companies = CRM_Model_Companies::get_all();
		View::load('CRM', 'admin/people/create',
			array('companies' => $companies));
	}

	public static function details($cid)
	{
		if(!$person = CRM_Model_People::get_by_cid($cid))
			Router::redirect('admin/crm/people');

		$avail = CRM_Model_Groups::get_all();
		$joined = CRM_Model_Groups::get_by_member($cid);

		// Loop through all groups, removing groups we've already joined
		foreach($avail as $k => $g)
		{
			foreach($joined as $j)
			{
				if($g['cid'] == $j['cid'])
					unset($avail[$k]);
			}
		}

		$person = CRM_Model_People::get_by_cid($cid);
		View::load('CRM', 'admin/people/details', array(
			'person' => $person,
			'avail' => $avail,
			'joined' => $joined
		));
	}

	public static function edit($cid)
	{
		if(!$person = CRM_Model_People::get_by_cid($cid))
			Router::redirect('admin/crm/people');

		View::load('CRM', 'admin/people/edit');
	}

	public static function delete($cid)
	{
		if(CRM_Model_People::delete($cid))
			Message::store(MSG_OK, 'Person deleted successfully.');
		else
			Message::store(MSG_ERR, 'Error deleting person. Please try again.');

		Router::redirect('admin/crm/people');
	}

	public static function join_group($person_cid)
	{
		if(!$person = CRM_Model_People::get_by_cid($person_cid))
			Router::redirect('admin/crm/people');

		if($_POST)
		{
			if(!CRM_Model_Groups::is_member($_POST['group_cid'], $person_cid))
			{
				if(CRM_Model_Groups::add_member($_POST['group_cid'], $person_cid))
					Message::store(MSG_OK, 'Person joined group successfully.');
				else
					Message::store(MSG_ERR, 'Error joining group. Please try again.');
			}
			else
				Message::store(MSG_ERR, 'This person is already a member of that group.');
		}

		Router::redirect('admin/crm/people/details/' . $person_cid);
	}

	public static function leave_group($person_cid, $group_cid)
	{
		if(!$person = CRM_Model_People::get_by_cid($person_cid))
			Router::redirect('admin/crm/people');

		if(CRM_Model_Groups::remove_member($person_cid, $group_cid))
			Message::store(MSG_OK, 'Person successfully removed from group.');
		else
			Message::store(MSG_ERR, 'Error leaving group. Please try again.');

		Router::redirect('admin/crm/people/details/' . $person_cid);
	}

	public static function import()
	{
		$report = array();
		$report_data = array(
			'attempted' => 0,
			'created' => 0
		);

		if($_FILES)
		{
			$file_data = Upload::save($_FILES['csv']);
			
			if($file_data)
			{
				$filepath = Upload::path($file_data['path'], $file_data['hash']);
				$handle = fopen($filepath, 'r');
				
				while(($data = fgetcsv($handle, 2048)))
				{
					if(count($data) < 1 || !strlen($data[0]))
					{
						Message::set('error', 'Incorrectly formatted CSV. Stopping import.');
						break;
					}

					$report_data['attempted']++;

					$fields = explode(',', CRM_CSV_FORMAT);
					$row = array();
					foreach($fields as $k => $v)
					{
						if(isset($data[$k]))
							$row[$v] = $data[$k];
						else
							$row[$v] = '';
					}

					if(CRM_Model_People::exists($row['email']))
						$row['status'] = 'Exists';
					else
					{
						$person_cid = CRM_Model_People::create($row);

						// Add person to groups if any
						if(!isset($_POST['group_cid']))
							$_POST['group_cid'] = array();

						foreach($_POST['group_cid'] as $group_cid)
							CRM_Model_Groups::add_member($group_cid, $person_cid);

						if($person_cid)
						{
							$report_data['created']++;
							$row['status'] = 'Created';
						}
						else
							$row['status'] = 'Unkown Error';
					}
					
					$report[] = $row;
				}

				// Remove CSV file
				@unlink($filepath);
			}
			else
				Message::set('error', Upload::error());
		}

		View::load('CRM', 'admin/people/import',
			array(
				'report' => $report, 
				'report_data' => $report_data,
				'groups' => CRM_Model_Groups::get_all()
			)
		);
	}

}
