<?php View::load('CRM', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Create Company</h2>
	<form method="post" action="<?php l('admin/crm/companies/create'); ?>">
		<ul>
			<li class="text medium">
				<label>Company Name</label>
				<input type="text" name="name" />
				<?php echo Validate::error('name'); ?>
			</li>
			<li class="buttons">
				<input type="submit" value="Create Company" />
			</li>
		</ul>
	</form>
</div>
