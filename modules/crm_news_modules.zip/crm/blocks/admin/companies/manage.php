<?php echo View::load('CRM', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Companies</h2>
	
	<table class="stripe" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<th>Name</th>
			<th style="text-align: right">Delete</th>
		</tr>

		<?php if($companies): ?>
			<?php foreach($companies as $company): ?>
				<tr>
					<td>
						<a href="<?php l('admin/crm/companies/details/%d', $company['cid']); ?>">
							<?php echo $company['name']; ?>
						</a>
					</td>
					<td align="right">
						<a href="<?php l('admin/crm/companies/delete/%d', $company['cid']); ?>">
							Delete
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php else: ?>
			<tr><td colspan="2"><em>No companies</em></td></tr>
		<?php endif; ?>
	</table>
</div>
