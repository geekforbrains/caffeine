<div class="area left short">
	<h3>Navigation</h3>
	<?php echo Menu::build('admin/crm/%s', 0); ?>
</div>
