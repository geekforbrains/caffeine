<?php View::load('CRM', 'admin/sidenav'); ?>

<div class="area right">
	<div class="area">
		<h2>Pending Sales</h2>
		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th>Name</th>
				<th style="text-align: right">Delete</th>
			</tr>

			<?php if($pending): ?>
				<?php foreach($pending as $sale): ?>
					<tr>
						<td>
							<a href="<?php l('admin/crm/sales/details/%d', $sale['cid']); ?>">
								<?php echo $sale['name']; ?>
							</a>
						</td>
						<td align="right">
							<a href="<?php l('admin/crm/sales/delete/%d', $sale['cid']); ?>">
								Delete
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr><td colspan="2"><em>No sales</em></td></tr>
			<?php endif; ?>
		</table>			
	</div>
</div>
