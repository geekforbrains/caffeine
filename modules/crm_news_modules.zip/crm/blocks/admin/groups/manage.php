<?php View::load('CRM', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Groups</h2>
	<table class="stripe" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<th>Name</th>
			<th style="text-align: right;">Delete</th>
		</tr>

		<?php if($groups): ?>
			<?php foreach($groups as $group): ?>
				<tr>
					<td>
						<?php /*<a href="<?php l('admin/crm/groups/details/%d', $group['cid']); ?>">*/ ?>
							<?php echo $group['name']; ?>
						<?php /*</a>*/ ?>
					</td>
					<td align="right">
						<a href="<?php l('admin/crm/groups/delete/%d', $group['cid']); ?>">
							Delete
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php else: ?>
			<tr><td colspan="2"><em>No groups</em></td></tr>
		<?php endif; ?>
	</table>
</div>
