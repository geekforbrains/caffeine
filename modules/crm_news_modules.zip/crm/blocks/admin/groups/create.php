<?php View::load('CRM', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Create Group</h2>
	<form method="post" action="<?php l('admin/crm/groups/create'); ?>">
		<ul>
			<li class="text medium">
				<label>Name</label>
				<input type="text" name="name" />
				<?php echo Validate::error('name'); ?>
			</li>
			<li class="buttons">
				<input type="submit" value="Create Group" />
			</li>
		</ul>
	</form>
</div>
