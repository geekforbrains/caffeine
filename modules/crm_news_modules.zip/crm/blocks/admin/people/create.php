<?php View::load('CRM', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Create Person</h2>
	<form method="post" action="<?php l('admin/crm/people/create'); ?>">
		<ul>
			<li class="select medium">
				<label>Company</label>
				<select name="company_cid">
					<option value="0">None</option>
					<?php foreach($companies as $company): ?>
						<option value="<?php echo $company['cid']; ?>">
							<?php echo $company['name']; ?>
						</option>
					<?php endforeach; ?>
				</select>
			</li>
			<li class="text medium">
				<label>Email</label>
				<input type="text" name="email" value="<?php echo Input::post('email'); ?>" />
				<?php echo Validate::error('email'); ?>
			</li>
			<li class="text medium">
				<label>Twitter</label>
				<input type="text" name="twitter" value="<?php echo Input::post('twitter'); ?>" />
			</li>
			<li class="text medium">
				<label>First Name</label>
				<input type="text" name="first_name" value="<?php echo Input::post('first_name'); ?>" />
			</li>
			<li class="text medium">
				<label>Last Name</label>
				<input type="text" name="last_name" value="<?php echo Input::post('last_name'); ?>" />
			</li>
			<li class="text medium">
				<label>Address</label>
				<input type="text" name="address" value="<?php echo Input::post('address'); ?>" />
			</li>
			<li class="text medium">
				<label>City</label>
				<input type="text" name="city" value="<?php echo Input::post('city'); ?>" />
			</li>
			<li class="text medium">
				<label>State / Province</label>
				<input type="text" name="province" value="<?php echo Input::post('province'); ?>" />
			</li>
			<li class="text medium">
				<label>Zip / Postal</label>
				<input type="text" name="postal" value="<?php echo Input::post('postal'); ?>" />
			</li>
			<li class="text medium">
				<label>Home Phone</label>
				<input type="text" name="phone_home" value="<?php echo Input::post('phone_home'); ?>" />
			</li>
			<li class="text medium">
				<label>Work Phone</label>
				<input type="text" name="phone_work" value="<?php echo Input::post('phone_work'); ?>" />
			</li>
			<li class="text medium">
				<label>Mobile Phone</label>
				<input type="text" name="phone_mobile" value="<?php echo Input::post('phone_mobile'); ?>" />
			</li>
			<li class="buttons">
				<input type="submit" value="Create Person" />
			</li>
		</ul>
	</form>
</div>
