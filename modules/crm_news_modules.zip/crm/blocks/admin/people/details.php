<img style="margin-bottom: 40px" src="http://gravatar.com/avatar/
	<?php echo md5(strtolower($person['email'])); ?>?d=mm&s=100" />

<div class="area">

	<?php /*
	<div class="fixed">
		<input type="button" value="Edit Person" />
	</div>
	*/ ?>

	<table border="0" cellpadding="0" cellspacing="0">
		<tr>
			<th width="100">Name</th>
			<td>
				<?php if(strlen($person['first_name']) || strlen($person['last_name'])): ?>
					<?php echo $person['first_name'] .' '.$person['last_name']; ?>
				<?php else: ?>
					-
				<?php endif; ?>
			</td>
		</tr>
		<tr>
			<th>Email</th>
			<td><?php echo $person['email']; ?></td>
		</tr>
	</table>
</div>

<div class="area">
	<div class="area">
		<h2>Groups</h2>
		
		<?php if($avail): ?>
			<div class="fixed">
				<form method="post" action="<?php l('admin/crm/people/details/%d/join-group', $person['cid']); ?>">
					<select name="group_cid">
						<?php foreach($avail as $group): ?>
							<option value="<?php echo $group['cid']; ?>">
								<?php echo $group['name']; ?>
							</option>
						<?php endforeach; ?>
					</select>
					<input type="submit" name="join" value="Join" />
				</form>
			</div>
		<?php endif; ?>

		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th>Name</th>
				<th style="text-align: right">Leave</th>
			</tr>

			<?php if($joined): ?>
				<?php foreach($joined as $group): ?>
					<tr>
						<td>
							<a href="<?php l('admin/crm/groups/details/%d', $group['cid']); ?>">
								<?php echo $group['name']; ?>
							</a>
						</td>
						<td align="right">
							<a href="<?php l('admin/crm/people/details/%d/leave-group/%d', $person['cid'], $group['cid']); ?>">
								Leave
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr><td colspan="2"><em>No groups</em></td></tr>
			<?php endif; ?>
		</table>
	</div>
</div>

