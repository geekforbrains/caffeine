<?php View::load('CRM', 'admin/sidenav'); ?>

<div class="area right">
	<h2>People</h2>
	<table class="stripe" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<th>Email</th>
			<th>Name</th>
			<th>Company</th>
			<th style="text-align: right">Delete</th>
		</tr>
		
		<?php if($people): ?>
			<?php foreach($people as $person): ?>
				<tr>
					<td>
						<a href="<?php l('admin/crm/people/details/%d', $person['cid']); ?>">
							<?php echo $person['email']; ?>
						</a>
					</td>
					<td>
						<?php if(strlen($person['first_name']) || strlen($person['last_name'])): ?>
							<a href="<?php l('admin/crm/people/details/%d', $person['cid']); ?>">
								<?php echo $person['first_name'] .' '. $person['last_name']; ?>
							</a>
						<?php else: ?>
							-
						<?php endif; ?>
					</td>
					<td>
						<?php if(strlen($person['company_name'])): ?>
							<a href="<?php l('admin/crm/companies/details/%d', $person['company_cid']); ?>">
								<?php echo $person['company_name']; ?>
							</a>
						<?php else: ?>
							-
						<?php endif; ?>
					</td>
					<td align="right">
						<a href="<?php l('admin/crm/people/delete/%d', $person['cid']); ?>">
							Delete
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php else: ?>
			<tr><td colspan="4"><em>No people</em></td></tr>
		<?php endif; ?>
	</table>
</div>
