<?php View::load('CRM', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Import People</h2>
	<form method="post" action="<?php echo Router::url('admin/crm/people/import'); ?>" enctype="multipart/form-data">
		<fieldset>
			<ul>
				<li class="text small">
					<label>CSV File</label>
					<input type="file" name="csv" />
				</li>
				<li class="select small">
					<label>Assign to Groups</label>
					<select name="group_cid[]" multiple="multiple">
						<?php if($groups): ?>
							<?php foreach($groups as $group): ?>
								<option value="<?php echo $group['cid']; ?>">
									<?php echo $group['name']; ?>
								</option>
							<?php endforeach; ?>
						<?php endif; ?>
					</select>
				<li>
					<input type="submit" value="Import" />
				</li>
			</ul>
		</fieldset>
	</form>

	<?php if($report): ?>
		<h2>
			Import Report 
			(<?php echo $report_data['created']; ?> of 
			<?php echo $report_data['attempted']; ?>)
		</h2>
		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th>Email</th>
				<th style="text-align: right">Status</th>
			</tr>

			<?php foreach($report as $row): ?>
				<tr>
					<td><?php echo $row['email']; ?></td>
					<td align="right"><?php echo $row['status']; ?></td>
				</tr>
			<?php endforeach; ?>
		</table>
	<?php endif; ?>
</div>
