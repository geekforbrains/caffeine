<?php 
class CRM_Model_Companies {

	public static function get_all()
	{
		Database::query('
			SELECT
				cc.*,
				c.created,
				c.updated
			FROM {crm_companies} cc
				JOIN {content} c ON c.id = cc.cid
			WHERE
				c.site_cid = %s
			',
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function get_by_cid($cid)
	{
		Database::query('
			SELECT
				cc.*,
				c.created,
				c.updated
			FROM {crm_companies} cc
				JOIN {content} c ON c.id = cc.cid
			WHERE cc.cid = %s
				AND c.site_cid = %s
			',
			$cid,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return Database::fetch_array();
		return false;
	}

	public static function exists($name)
	{
		Database::query('
			SELECT 
				cc.cid 
			FROM {crm_companies} cc
				JOIN {content} c ON c.id = cc.cid
			WHERE cc.name LIKE %s
				AND c.site_cid = %s
			', 
			$name,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return true;
		return false;
	}

	public static function create($name)
	{
		$cid = Content::create(CRM_TYPE_COMPANY);
		return Database::insert('crm_companies', array(
			'cid' => $cid,
			'name' => $name
		));
	}

	public static function delete($cid)
	{
		if(self::get_by_cid($cid))
		{
			Content::delete($cid);

			// Update all people associated with this company to cid 0
			Database::update('crm_people',
				array('company_cid' => 0),
				array('company_cid' => $cid)
			);

			return Database::delete('crm_companies', array('cid' => $cid));
		}

		return false;
	}

}
