<?php
class CRM_Admin_Sales {

	public static function manage()
	{
		$pending = CRM_Model_Sales::get_all('pending');
		$won = CRM_Model_Sales::get_all('won');
		$lost = CRM_Model_Sales::get_all('lost');

		View::load('CRM', 'admin/sales/manage', array(
			'pending' => $pending,
			'won' => $pending,
			'lost' => $pending
		));
	}

	public static function create()
	{
		if($_POST)
		{
			Validate::check('related_cid', 'Person', array('required'));
			Validate::check('name', 'Name', array('required'));
			Validate::check('amount', 'Amount', array('required'));
			Validate::check('rate', 'Rate', array('required'));

			if(Validate::passed())
			{
				$status = CRM_Model_Sales::create(
					$_POST['related_cid'],
					$_POST['name'],
					$_POST['type'],
					$_POST['amount'],
					$_POST['rate']
				));

				if($status)
				{
					Message::store(MSG_OK, 'Sale created successfully.');
					Router::redirect('admin/crm/sales');
				}
				else
					Message::set(MSG_ERR, 'Error creating sale. Please try again.');
			}
		}

		$people = CRM_Model_People::get_all():
		View::load('CRM', 'admin/sales/create',
			array('people' => $people));
	}

	public static function details($cid)
	{
		View::load('CRM', 'admin/sales/details');
	}

	public static function edit($cid)
	{
		View::load('CRM', 'admin/sales/edit');
	}

	public static function delete($cid)
	{
		if(CRM_Model_Sales::delete($cid))
			Message::store(MSG_OK, 'Sale deleted successfully.');
		else
			Message::store(MSG_ERR, 'Error deleting sale. Please try again.');

		Router::redirect('admin/crm/sales');
	}

}
