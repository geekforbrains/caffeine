<?php if(!defined('CAFFEINE_ROOT')) die ('No direct script access allowed.');
/**
 * =============================================================================
 * CRM Configurations
 * =============================================================================
 */
define('CRM_TAB', 'CRM'); // So we can easily change the tab name in admin

/**
 * =============================================================================
 * CRM Constants
 * =============================================================================
 */
define('CRM_TYPE_COMPANY', 'crm_company');
define('CRM_TYPE_PERSON', 'crm_person');
define('CRM_TYPE_GROUP', 'crm_group');
define('CRM_TYPE_SALE', 'crm_sale');
define('CRM_TYPE_NOTE', 'crm_note');

// The order in which CSV fields will be processed
define('CRM_CSV_FORMAT', 'email,first_name,last_name,address,city,province,postal,phone_home,phone_work,phone_mobile,twitter');
