<?php
class Newsletter_Model_Templates {

	public static function get_all()
	{
		Database::query('
			SELECT
				nt.*,
				c.created,
				c.updated
			FROM {newsletter_templates} nt
				JOIN {content} c ON c.id = nt.cid
			WHERE
				c.site_cid = %s
			',
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function get_by_cid($cid)
	{
		Database::query('
			SELECT
				nt.*,
				c.created,
				c.updated
			FROM {newsletter_templates} nt
				JOIN {content} c ON c.id = nt.cid
			WHERE nt.cid = %s
				AND c.site_cid = %s
			',
			$cid,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return Database::fetch_array();
		return false;
	}

	public static function get_fields($cid)
	{
		Database::query('SELECT * FROM {newsletter_template_fields} WHERE template_cid = %s', $cid);
		return Database::fetch_all();
	}

	public static function exists($name)
	{
		Database::query('
			SELECT
				nt.cid
			FROM {newsletter_templates} nt
				JOIN {content} c ON c.id = nt.cid
			WHERE nt.name LIKE %s
				AND c.site_cid = %s
			',
			$name,
			User::current_site()
		);

		if(Database::num_rows() > 0)
			return true;
		return false;
	}

	public static function create($name, $html)
	{
		$cid = Content::create(NEWSLETTER_TYPE_TEMPLATE);

		Database::insert('newsletter_templates', array(
			'cid' => $cid,
			'name' => $name,
			'html' => $html
		));

		return $cid;
	}

	public static function update($cid, $name)
	{
		Content::update($cid);
		return Database::update('newsletter_templates', 
			array('name' => $name),
			array('cid' => $cid
		));
	}

	public static function add_file($template_cid, $media_cid)
	{
		Database::insert('newsletter_template_files', array(
			'template_cid' => $template_cid,
			'media_cid' => $media_cid
		));
	}

	public static function add_field($template_cid, $tag, $type, $field, $name, $options, $fields)
	{
		$cid = Content::create(NEWSLETTER_TYPE_TEMPLATE_FIELD);
		$status = Database::insert('newsletter_template_fields', array(
			'cid' => $cid,
			'template_cid' => $template_cid,
			'tag' => $tag,
			'type' => $type,
			'field' => $field,
			'name' => $name,
			'options' => ($options) ? serialize($options) : null,
			'fields' => ($fields) ? serialize($fields) : null
		));

		if($status)
			return $cid;
		return false;
	}

	public static function delete($cid)
	{
		if(self::get_by_cid($cid))
		{
			Content::delete($cid);

			// Delete fields from content
			Database::query('SELECT * FROM {newsletter_template_fields} WHERE template_cid = %s', $cid);
			$fields = Database::fetch_all();
			foreach($fields as $field)
				Content::delete($field['cid']);

			// Delete media files
			Database::query('SELECT * FROM {newsletter_template_files} WHERE template_cid = %s', $cid);
			$files = Database::fetch_all();
			foreach($files as $file)
				Media::delete($file['media_cid']);

			Database::delete('newsletter_template_fields', array('template_cid' => $cid));
			Database::delete('newsletter_template_files', array('template_cid' => $cid));
			return Database::delete('newsletter_templates', array('cid' => $cid));
		}

		return false;
	}

}
