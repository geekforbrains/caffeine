<?php
class Newsletter_Admin_Templates {

	public static function manage()
	{
		$templates = Newsletter_Model_Templates::get_all();
		View::load('Newsletter', 'admin/templates/manage',
			array('templates' => $templates));
	}

	public static function create()
	{
		if($_POST)
		{
			Validate::check('name', 'Name', array('required'));	

			if(Validate::passed())
			{
				if(Newsletter_Model_Templates::exists($_POST['name']))
					Message::set(MSG_ERR, 'A template with that name already exists.');

				elseif($zipfile = Upload::unzip($_FILES['zip']))
				{
					$template = null;
					$files = array();

					// First, delete zip file
					@unlink(Upload::path($zipfile['path'] . $zipfile['hash']));

					// Look for template file
					foreach($zipfile['files'] as $k => $data)
					{
						if($data['name'] == NEWSLETTER_TEMPLATE_FILE)
							$template = $data;
						else
							$files[] = $data;
					}

					// If no template file found, error
					if(!is_null($template))
					{
						$template_path = Upload::path($template['path'], $template['hash']);
						$template_html = file_get_contents($template_path);
						$template_cid = Newsletter_Model_Templates::create($_POST['name'], $template_html);

						// Delete template file, because we store its contents in the database
						@unlink($template_path);

						// Generate fields
						self::_parse_fields($template_cid, $template_html);

						foreach($files as $data)
						{
							$media_type = Media::determine_media_type($data['type']);
							$media_cid = Media_Model::create_file($data, $media_type);
							Newsletter_Model_Templates::add_file($template_cid, $media_cid);
						}


						Message::store(MSG_OK, 'Template created successfully.');
						Router::redirect('admin/newsletter/templates');
					}	
					else
						Message::set(MSG_ERR, 'Zip file is missing %s.', NEWSLETTER_TEMPLATE_FILE);
				}
				else
					Message::set(MSG_ERR, Upload::error());
			}
		}

		View::load('Newsletter', 'admin/templates/create');
	}

	public static function edit($cid) 
	{
		if(!Newsletter_Model_Templates::get_by_cid($cid))
			Router::redirect('admin/newsletter/templates');

		if($_POST)
		{
			Validate::check('name', 'Name', array('required'));

			if(Validate::passed())
			{
				if(!Newsletter_Model_Templates::exists($_POST['name']))
				{
					if(Newsletter_Model_Templates::update($cid, $_POST['name']))
					{
						Message::store(MSG_OK, 'Template updated successfully.');
						Router::redirect('admin/newsletter/templates');
					}
					else
						Message::set(MSG_ERR, 'Error updating template. Please try again.');
				}
				else
					Message::set(MSG_ERR, 'A template with that name already exists.');
			}
		}

		$template = Newsletter_Model_Templates::get_by_cid($cid);
		View::load('Newsletter', 'admin/templates/edit',
			array('template' => $template));
	}

	public static function delete($cid) 
	{
		if(Newsletter_Model_Templates::delete($cid))
			Message::store(MSG_OK, 'Template deleted successfully.');
		else
			Message::store(MSG_ERR, 'Error deleting template. Please try again.');

		Router::redirect('admin/newsletter/templates');
	}

	// Parses fields out of a templates html and adds them to the database
	private static function _parse_fields($template_cid, $html)
	{
		$regex = '/{([\/\w]+):([^\[}]+)?[\[]?(.*?)[\]]?}/s';
		$tags = array();

		if(preg_match_all($regex, $html, $matches, PREG_SET_ORDER))
		{
			foreach($matches as $m)
			{
				$options = array();
				if(isset($m[3]))
				{
					$bits = explode(',', $m[3]);
					foreach($bits as $bit)
					{
						$option = explode('=', $bit);
						if(isset($option[0]) && isset($option[1]))
							$options[trim($option[0])] = trim($option[1]);
					}
				}

				$tags[] = array(
					'tag' => $m[0],
					'type' => isset($m[1]) ? $m[1] : null,
					'field' => isset($m[2]) ? $m[2] : null,
					'name' => isset($m[2]) ? ucwords(str_replace('_', ' ', $m[2])) : null,
					'options' => $options,
					'fields' => array()
				);
			}
		}

		/*
		$in_loop = false;
		foreach($tags as $k => $tag)
		{
			if(strstr($tag['type'], 'module'))
			{
				$in_loop = ($in_loop) ? false : true;
				$loop =& $tags[$k];

				if(!$in_loop)
					unset($tags[$k]); // If leaving loop, remove trailing loop tag
			}
			elseif($in_loop)
			{
				unset($tags[$k]);
				$loop['fields'][] = $tag['field'];
			}
		}
		*/

		$current_type = null;
		foreach($tags as $k => $tag)
		{
			if($tag['type'] == 'module')
			{
				$loop =& $tags[$k];
				$current_type = $loop['field'];
			}
			elseif($tag['type'] == $current_type)
			{
				$loop['fields'][] = $tag['field'];
				unset($tags[$k]);
			}
		}

		// Store fields
		foreach($tags as $tag)
		{
			Newsletter_Model_Templates::add_field(
				$template_cid,
				$tag['tag'],
				$tag['type'],
				$tag['field'],
				$tag['name'],
				$tag['options'],
				$tag['fields']
			);
		}
	}

}
