<?php 
class Newsletter_Admin_Emails {

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	public static function overview()
	{
		$scheduled = Newsletter_Model_Emails::get_scheduled();
		$sent = Newsletter_Model_Emails::get_sent();

		View::load('Newsletter', 'admin/emails/overview',
			array(
				'scheduled' => $scheduled,
				'sent' => $sent
			)
		);
	}

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	public static function manage()
	{
		$emails = Newsletter_Model_Emails::get_all(1);
		$drafts = Newsletter_Model_Emails::get_all(0);

		View::load('Newsletter', 'admin/emails/manage', array(
			'emails' => $emails,
			'drafts' => $drafts
		));
	}

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	public static function create()
	{
		if($_POST)
		{
			Validate::check('template_cid', 'Template', array('required'));
			Validate::check('subject', 'Subject', array('required')); 

			if(Validate::passed())
			{
				$cid = Newsletter_Model_Emails::create($_POST['template_cid'], $_POST['subject']);
				Router::redirect('admin/newsletter/emails/edit/' . $cid);
			}
		}

		$templates = Newsletter_Model_Templates::get_all();
		View::load('Newsletter', 'admin/emails/create',
			array('templates' => $templates));
	}

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	public static function details($cache_cid)
	{
		$email = Newsletter_Model_Emails::get_sent_by_cid($cache_cid);
		$links = Newsletter_Model_Emails::get_links_by_cache_cid($cache_cid);

		View::load('Newsletter', 'admin/emails/details',
			array(
				'email' => $email,
				'links' => $links
			)
		);
	}

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	public static function edit($cid)
	{
		$email = Newsletter_Model_Emails::get_by_cid($cid);
		$fields = Newsletter_Model_Emails::get_fields($cid);

		// Sort fields into static and module
		$static_fields = array();
		$module_fields = array();

		foreach($fields as $field)
		{
			if($field['type'] == 'module')
			{
				if(isset($module_fields[$field['cid']]))
					$module_fields[$field['cid']]['values'][] = $field['value'];
				else
				{
					$field['items'] = call_user_func(array(sprintf('%s_Events', $field['field']), 'newsletter_items')); // Module callback
					$field['values'] = array();
					if($field['value'])
						$field['values'][] = $field['value'];
					unset($field['value']);
					$module_fields[$field['cid']] = $field;
				}
			}
			else
				$static_fields[] = $field;
		}

		if($_POST)
		{
			Validate::check('subject', 'Subject', array('required'));

			// Handle static fields
			$images = array();
			$text = array();
			foreach($static_fields as $field)
			{
				// Validate anything that isn't an image or a loop tag
				if($field['type'] != 'image')
				{
					$text[] = $field;
					Validate::check('f' . $field['cid'], $field['name'], array('required'));
				}
				else
					$images[] = $field;
			}

			// Handle module fields
			foreach($module_fields as $field)
			{
				$count = Newsletter_Model_Emails::get_field_count($cid, $field['cid']);
				if(isset($_POST['f' . $field['cid']]) && $count <= 0)
					Validate::check('f' . $field['cid'], $field['name'], array('required'));
			}

			if(Validate::passed())
			{
				$status = true;
				$published = (isset($_POST['published'])) ? 1 : 0;

				// Update text fields
				foreach($text as $field)
				{
					$count = Newsletter_Model_Emails::get_field_count($cid, $field['cid']);
					//$limit = (isset($field['options']['limit'])) ? $field['options']['limit'] : false;

					// If a value is already set, update
					if($count > 0)
						Newsletter_Model_Emails::update_field($cid, $field['cid'], Input::post('f' . $field['cid']));

					// Otherwise, insert
					else
						Newsletter_Model_Emails::insert_field($cid, $field['cid'], Input::post('f' . $field['cid']));
				}

				// Upload any images set, and store the media CID as the field value
				foreach($images as $image)
				{
					if(isset($_FILES['f' . $image['cid']]))
					{
						if($media_cid = Media::add('f' . $image['cid']))
							Newsletter_Model_Emails::insert_field($cid, $image['cid'], strval($media_cid));
						else
						{
							$status = false;
							Message::set(MSG_ERR, Media::error());
						}
					}
				}

				// Handle module fields
				foreach($module_fields as $field)
				{
					if(!isset($_POST['f' . $field['cid']]) || !strlen($_POST['f' . $field['cid']]))
						continue;

					$count = Newsletter_Model_Emails::get_field_count($cid, $field['cid']);
					$limit = (isset($field['options']['limit'])) ? $field['options']['limit'] : false;

					// If no limit, or we haven't reached our limit, insert
					if($limit === false || $count < $limit)
					{
						if(!Newsletter_Model_Emails::value_exists($cid, Input::post('f' . $field['cid'])))
							Newsletter_Model_Emails::insert_field($cid, $field['cid'], Input::post('f' . $field['cid']));
						else
						{
							Message::set(MSG_ERR, 'That value has already been added.');
							$status = false;
						}
					}
					else
					{
						Message::set(MSG_ERR, 'Limit reached for "' . $field['name'] . '" field.');
						$status = false;
					}
				}

				// If no errors up to this point, update email
				if($status)
				{
					// Update email with subject and body
					Newsletter_Model_Emails::update($cid, $_POST['subject'], $_POST['body'], $published);
					Message::store(MSG_OK, 'Email saved!');
					Router::redirect('admin/newsletter/emails/edit/' . $cid);
					//$email = Newsletter_Model_Emails::get_by_cid($cid); // Re-get updated email
				}
			}
		}

		View::load('Newsletter', 'admin/emails/edit', array(
			'email' => $email,
			'static_fields' => $static_fields,
			'module_fields' => $module_fields
		));
	}

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	public static function delete_image($email_cid, $field_cid)
	{
		$field = Newsletter_Model_Emails::get_field($email_cid, $field_cid);
		Newsletter_Model_Emails::clear_field($email_cid, $field_cid);
		Media::delete($field['value']);

		Message::store(MSG_OK, 'Image deleted successfully.');
		Router::redirect('admin/newsletter/emails/edit/' . $email_cid);
	}

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	// Deletes a module value from the emails field data
	public static function delete_value($email_cid, $value_hash)
	{
		if(Newsletter_Model_Emails::delete_value($email_cid, $value_hash))
			Message::store(MSG_OK, 'Value deleted successfully.');
		else
			Message::store(MSG_ERR, 'Error deleting value. Please try again.');
	
		Router::redirect('admin/newsletter/emails/edit/' . $email_cid);
	}

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	public static function delete($cid)
	{
		if(Newsletter_Model_Emails::delete($cid))
			Message::store(MSG_OK, 'Email deleted successfully.');
		else
			Message::store(MSG_ERR, 'Error deleting email. Please try again.');

		Router::redirect('admin/newsletter/emails/manage');
	}

	/**
	 * -------------------------------------------------------------------------
	 * TODO
	 * -------------------------------------------------------------------------
	 */
	public static function send()
	{
		if($_POST)
		{
			Validate::check('email_cid', 'Email', array('required'));
			Validate::check('group_cid', 'Groups', array('required'));

			if(Validate::passed())
			{
				$email = Newsletter_Model_Emails::get_by_cid($_POST['email_cid']);
				$fields = Newsletter_Model_Emails::get_fields($_POST['email_cid']);
				$cache = $email['html'];

				// Replace default tags
				$cache = str_replace('{subject}', $email['subject'], $cache);
				$cache = str_replace('{body}', $email['body'], $cache);

				/*
				// Replace custom template fields with values set for this email
				foreach($fields as $field)
				{
					// Replace custom text fields directly
					if($field['type'] != 'image')
						$cache = str_replace($field['tag'], $field['value'], $cache);

					// Replace custom images with "image<cid>" so we can parse it when sending
					// See Newsletter_Sender
					else
						$cache = str_replace($field['tag'], 'image' . $field['value'], $cache);
				}
				*/

				// Replace static and module fields
				$block_cache = array();
				foreach($fields as $field)
				{
					// Images are parsed differently, ignore them
					if($field['type'] == 'image')
						continue;

					if($field['type'] != 'module')
					{
						$cache = str_replace($field['tag'], $field['value'], $cache);
					}

					else
					{
						// Use data from module to replace tags in template
						// Get the html block for this module
						$regex = sprintf('%s(.*?){\/module}', $field['tag']);
						$regex = str_replace('[', '\[', $regex);
						$regex = str_replace(']', '\]', $regex);

						if(!isset($block_cache[$field['field']]))
						{
							$block_cache[$field['field']]['regex'] = $regex; // Store for cache replacement
							$block_cache[$field['field']]['block'] = ''; // Store data html to inject into cache
						}

						// Split value into bits so we can send module key to get content
						$bits = explode(':', $field['value']);
						$data = call_user_func(array(sprintf('%s_Events', $field['field']), 'newsletter_data'), $bits[0]);

						if(preg_match('/' . $regex. '/s', $cache, $matches))
						{
							$holder = $matches[1];
							foreach($field['fields'] as $key)
							{
								if(isset($data[$key]))
									$holder = str_replace(sprintf('{%s:%s}', $field['field'], $key), $data[$key], $holder);
							}	
							$block_cache[$field['field']]['block'] .= $holder;
						}
					}
				}

				// Inject any module data built in previous step
				foreach($block_cache as $block)
				{	
					if(strlen($block['block']))
						$cache = preg_replace('/' . $block['regex'] . '/s', $block['block'], $cache);
				}

				// Convert template images to media urls
				$images = Newsletter_Model_Emails::get_template_files_by_email_cid($_POST['email_cid']);
				foreach($images as $image)
				{
					$media = Media::get($image['media_cid']);
					$media_url = Router::full_url('media/image/%d', $media['cid']);
					$cache = str_replace($media['name'], $media_url, $cache);
				}

				// Convert dynamic field images to media urls
				$images = Newsletter_Model_Emails::get_field_images_by_email_cid($_POST['email_cid']);
				foreach($images as $image)
				{
					$media = Media::get($image['value']);
					$media_url = Router::full_url('media/image/%d', $media['cid']);
					$cache = str_replace($image['tag'], $media_url, $cache);
				}

				// Store cache for sending
				$cache_cid = Newsletter_Model_Emails::create_cache($_POST['email_cid'], $email['subject'], $cache);

				// Get people from selected groups
				$people = array();
				foreach($_POST['group_cid'] as $group_cid)
				{
					$members = CRM_Model_People::get_by_group($group_cid);
					foreach($members as $person)
						if(!isset($people[$person['cid']]))
							$people[$person['cid']] = $person;
				}

				// Add people to queue
				Newsletter_Model_Emails::add_to_queue($cache_cid, $people);

				// Schedule email
				$timestamp = strtotime(sprintf('%s %s', $_POST['date'], $_POST['time']));
				Newsletter_Model_Emails::schedule_email($cache_cid, $timestamp, count($people));

				Message::store(MSG_OK, 'Email has been successfully scheduled for sending.');
				Router::redirect('admin/newsletter/emails/overview');
			}
		}

		$emails = Newsletter_Model_Emails::get_all(1);
		$groups = CRM_Model_Groups::get_all();

		View::load('Newsletter', 'admin/emails/send', array(
			'emails' => $emails,
			'groups' => $groups
		));
	}

}
