<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Edit Template</h2>
	<form method="post" action="<?php l('admin/newsletter/templates/edit/%d', $template['cid']); ?>">
		<ul>
			<li class="text medium">
				<label>Name</label>
				<input type="text" name="name" value="<?php echo $template['name']; ?>" />
				<?php echo Validate::error('name'); ?>
			</li>
			<li class="buttons">
				<input type="submit" value="Update Template" />
			</li>
		</ul>
	</form>
</div>
