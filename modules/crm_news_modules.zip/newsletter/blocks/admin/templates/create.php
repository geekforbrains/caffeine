<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Create Template</h2>
	<form method="post" action="<?php l('admin/newsletter/templates/create'); ?>" enctype="multipart/form-data">
		<ul>
			<li class="text medium">
				<label>Name</label>
				<input type="text" name="name" value="<?php echo Input::post('name'); ?>" />
				<?php echo Validate::error('name'); ?>
			</li>
			<li class="text medium">
				<label>Template</label>
				<input type="file" name="zip" />
			</li>
			<li class="buttons">
				<input type="submit" value="Create Template" />
			</li>
		</ul>
	</form>
</div>
