<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Templates</h2>
	<table class="stripe" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<th>Name</th>
			<th style="text-align: right">Delete</th>
		</tr>
		
		<?php if($templates): ?>
			<?php foreach($templates as $template): ?>
				<tr>
					<td>
						<a href="<?php l('admin/newsletter/templates/edit/%d', $template['cid']); ?>">
							<?php echo $template['name']; ?>
						</a>
					</td>
					<td align="right">
						<a href="<?php l('admin/newsletter/templates/delete/%d', $template['cid']); ?>">
							Delete
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php else: ?>
			<tr><td colspan="2"><em>No templates</em></td></tr>
		<?php endif; ?>
	</table>
</div>

