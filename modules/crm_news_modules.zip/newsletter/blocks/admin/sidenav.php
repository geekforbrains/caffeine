<div class="area left short">
	<h3>Navigation</h3>
	<?php echo Menu::build('admin/%s/%s', 0); ?>
</div>
