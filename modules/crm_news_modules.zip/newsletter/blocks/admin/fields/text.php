<li class="text medium">
	<label><?php echo $field['name']; ?></label>
	<input type="text" name="f<?php echo $field['cid']; ?>" value="<?php echo $field['value']; ?>" />
	<?php Validate::error('f' . $field['cid']); ?>
</li>
