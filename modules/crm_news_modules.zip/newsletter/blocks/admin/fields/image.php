<li class="text medium">
	<label><?php echo $field['name']; ?></label>

	<?php if(!strlen($field['value'])): ?>

		<input type="file" name="f<?php echo $field['cid']; ?>" />
		<?php echo Validate::error('f'. $field['cid']); ?>

	<?php else: ?>
	
		<img src="<?php l('media/image/%d/0/75/75', $field['value']); ?>" /><br />
		<a href="<?php echo Router::current_url(); ?>/delete-image/<?php echo $field['cid']; ?>">
			Delete Image
		</a>

	<?php endif; ?>
</li>
