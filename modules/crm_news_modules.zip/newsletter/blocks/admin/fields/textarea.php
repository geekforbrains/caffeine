<li class="textarea medium">
	<label><?php echo $field['name']; ?></label>
	<textarea class="tinymce" name="f<?php echo $field['cid']; ?>"><?php echo $field['value']; ?></textarea>
	<?php Validate::error('f' . $field['cid']); ?>
</li>
