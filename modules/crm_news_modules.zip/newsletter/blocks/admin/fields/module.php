<div class="area">
	<h2><?php echo $field['name']; ?></h2>
	<ul>
		<li class="select small">
			<?php /*
			<label>
				<?php echo $field['name']; ?>
				<?php if(isset($field['options']['limit']) && $field['options']['limit'] > 1): ?>
					<small><em>(Add up to <?php echo $field['options']['limit']; ?>)</em></small>
				<?php endif; ?>
			</label>
			*/ ?>

			<?php if(!isset($field['options']['limit']) || count($field['values']) < $field['options']['limit']): ?>
				<div style="margin-bottom: 30px;">
					<select name="f<?php echo $field['cid']; ?>">
						<option value="">Choose One</option>

						<?php foreach($field['items'] as $key => $value): ?>
							<option value="<?php echo $key; ?>:<?php echo $value; ?>">
								<?php echo $value; ?>
							</option>
						<?php endforeach; ?>
					</select>
					<input type="submit" value="Add" />
					<?php echo Validate::error('f' . $field['cid']); ?>
				</div>
			<?php endif; ?>

			<?php if($field['values']): ?>
				<table class="stripe" border="0" cellpadding="0" cellspacing="0">
					<tr>
						<th>Items</th>
						<th style="text-align: right">Delete</th>
					</tr>
					<?php foreach($field['values'] as $value): ?>
						<?php $bits = explode(':', $value); ?>
						<tr>
							<td><?php echo $bits[1]; ?></td>
							<td align="right">
								<a href="<?php echo l('admin/newsletter/emails/edit/%d/delete-value/%s', $email['cid'], md5($value)); ?>">
									Delete
								</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endif; ?>
		</li>
	</ul>
</div>
