<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<form method="post" action="<?php l('admin/newsletter/emails/edit/%d', $email['cid']); ?>" enctype="multipart/form-data">
		<div class="area">
			<h2>Edit Email</h2>
			<ul>
				<li class="text medium">
					<label>Subject</label>
					<input type="text" name="subject" value="<?php echo $email['subject']; ?>" />
					<?php echo Validate::error('subject'); ?>
				</li>
				<li class="textarea full">
					<label>Body</label>
					<textarea class="tinymce" name="body"><?php echo $email['body']; ?></textarea>
				</li>

				<?php foreach($static_fields as $field): ?>
					<?php View::load('Newsletter', 'admin/fields/' . $field['type'], array('field' => $field)); ?>
				<?php endforeach; ?>

				<li class="buttons">
					<input type="submit" name="draft" value="Save as Draft" />
					<input type="submit" name="published" value="Save" />
					<!--<a href="#" target="_blank">Preview</a>-->
				</li>
			</ul>
		</div>

		<?php /*
		<?php if($module_fields): ?>
			<div class="area">
				<h2>Modules</h2>
				<ul>
					<?php foreach($module_fields as $field): ?>
						<?php View::load('Newsletter', 'admin/fields/module', array('email' => $email, 'field' => $field)); ?>
					<?php endforeach; ?>

					<li class="buttons">
						<input type="submit" name="draft" value="Save as Draft" />
						<input type="submit" name="published" value="Save" />
						<!--<a href="#" target="_blank">Preview</a>-->
					</li>
				</ul>
			</div>
		<?php endif ?>
		*/ ?>

		<?php if($module_fields): ?>
			<?php foreach($module_fields as $field): ?>
				<?php View::load('Newsletter', 'admin/fields/module', array('email' => $email, 'field' => $field)); ?>
			<?php endforeach; ?>
		<?php endif ?>
	</form>
</div>
