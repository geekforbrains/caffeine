<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<div class="area">
		<h2><?php echo $email['subject']; ?></h2>
		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th width="125">Sent On</th>
				<td><?php echo date('M jS, g:i A', $email['scheduled_for']); ?></td>
			</tr>
			<tr>
				<th>Total Sent</th>
				<td><?php echo $email['total_sent']; ?></td>
			</tr>
			<tr>
				<th>Total Opened</th>
				<td>
					<?php echo $email['total_opened']; ?>
					<em>(<?php echo number_format($email['total_opened'] / $email['total_sent'] * 100); ?>)%</em>
				</td>
			</tr>
		</table>
	</div>

	<div class="area">
		<h2>Link Statistics</h2>
		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th>URL</th>
				<th style="text-align: right">Clicks</th>
			</tr>

			<?php if($links): ?>
				<?php foreach($links as $link): ?>
					<tr>
						<td><?php echo $link['url']; ?></td>
						<td align="right"><?php echo $link['clicks']; ?></td>
					</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr><td colspan="2"><em>No links found in email</em></td></tr>
			<?php endif; ?>
		</table>
	</div>
</div>

