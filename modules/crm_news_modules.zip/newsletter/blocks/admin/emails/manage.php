<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<div class="area">
		<h2>Emails</h2>
		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th>Subject</th>
				<th style="text-align: right">Delete</th>
			</tr>

			<?php if($emails): ?>
				<?php foreach($emails as $email): ?>
					<tr>
						<td>
							<a href="<?php l('admin/newsletter/emails/edit/%d', $email['cid']); ?>">
								<?php echo $email['subject']; ?>
							</a>
						</td>
						<td align="right">
							<a href="<?php l('admin/newsletter/emails/delete/%d', $email['cid']); ?>">
								Delete
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr><td colspan="2"><em>No emails</em></td></tr>
			<?php endif; ?>
		</table>
	</div>

	<div class="area">
		<h2>Drafts</h2>
		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th>Subject</th>
				<th style="text-align: right">Delete</th>
			</tr>

			<?php if($drafts): ?>
				<?php foreach($drafts as $email): ?>
					<tr>
						<td>
							<a href="<?php l('admin/newsletter/emails/edit/%d', $email['cid']); ?>">
								<?php echo $email['subject']; ?>
							</a>
						</td>
						<td align="right">
							<a href="<?php l('admin/newsletter/emails/delete/%d', $email['cid']); ?>">
								Delete
							</a>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr><td colspan="2"><em>No drafts</em></td></tr>
			<?php endif; ?>
		</table>
	</div>
</div>
