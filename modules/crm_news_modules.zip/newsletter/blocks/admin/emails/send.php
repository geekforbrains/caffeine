<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Send Email</h2>
	<form method="post" action="<?php l('admin/newsletter/emails/send'); ?>">
		<ul>
			<li class="select medium">
				<label>Email</label>
				<select name="email_cid">
					<option value="">-</option>
					<?php foreach($emails as $email): ?>
						<option value="<?php echo $email['cid']; ?>">
							<?php echo $email['subject']; ?>
						</option>
					<?php endforeach; ?>
				</select>
				<?php echo Validate::error('email_cid'); ?>
			</li>
			<li class="select medium">
				<label>Groups <em>(<a href="<?php l('admin/crm/groups/manage'); ?>">manage</a>)</em></label>
				<select name="group_cid[]" multiple="multiple">
					<?php foreach($groups as $group): ?>
						<option value="<?php echo $group['cid']; ?>">
							<?php echo $group['name']; ?>
						</option>
					<?php endforeach; ?>
				</select>
				<?php echo Validate::error('group_cid'); ?>
			</li>
			<li class="text tiny">
				<label>Send On <small><em>(YYYY-MM-DD) at (HH:MM AM/PM)</em></small></label>
				<input class="cal" type="text" name="date" value="<?php echo date('Y-m-d'); ?>" /> at
				<input type="text" name="time" value="<?php echo date('g:i A'); ?>" />
			</li>
			<li class="buttons">
				<input type="submit" value="Send Email" />
			</li>
		</ul>
	</form>
</div>
