<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<h2>Create Email</h2>
	<form method="post" action="<?php l('admin/newsletter/emails/create'); ?>">
		<ul>
			<li class="select medium">
				<label>Template</label>
				<select name="template_cid">
					<option value="">-</option>
					<?php foreach($templates as $template): ?>
						<option value="<?php echo $template['cid']; ?>">
							<?php echo $template['name']; ?>
						</option>
					<?php endforeach; ?>
				</select>
				<?php echo Validate::error('template_cid'); ?>
			</li>
			<li class="text medium">
				<label>Subject</label>
				<input type="text" name="subject" value="<?php echo Input::post('subject'); ?>" />
				<?php echo Validate::error('subject'); ?>
			</li>
			<li class="buttons">
				<input type="submit" value="Create Email" />
			</li>
		</ul>
	</form>
</div>
