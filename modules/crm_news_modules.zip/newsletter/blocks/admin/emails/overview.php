<?php View::load('Newsletter', 'admin/sidenav'); ?>

<div class="area right">
	<div class="area">
		<h2>Scheduled</h2>
		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th>Subject</th>
				<th style="text-align: right">Scheduled For</th>
			</tr>

			<?php if($scheduled): ?>
				<?php foreach($scheduled as $email): ?>
					<tr>
						<td><?php echo $email['subject']; ?></td>
						<td align="right"><?php echo date('M jS, g:i A', $email['scheduled_for']); ?></td>
					</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr><td colspan="2"><em>No scheduled emails</em></td></tr>
			<?php endif; ?>
		</table>
	</div>

	<div class="area">
		<h2>Sent</h2>
		<table class="stripe" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<th>Subject</th>
				<th>Sent</th>
				<th>Opened</th>
				<th style="text-align: right">Sent On</th>
			</tr>

			<?php if($sent): ?>
				<?php foreach($sent as $email): ?>
					<tr>
						<td>
							<a href="<?php l('admin/newsletter/emails/details/%d', $email['cache_cid']); ?>">
								<?php echo $email['subject']; ?>
							</a>
						</td>
						<td><?php echo $email['total_sent']; ?></td>
						<td>
							<?php echo $email['total_opened']; ?>
							<em>(<?php echo number_format(($email['total_opened'] / $email['total_sent']) * 100); ?>%)</em>
						</td>
						<td align="right"><?php echo date('M jS, g:i A', $email['scheduled_for']); ?></td>
					</tr>
				<?php endforeach; ?>
			<?php else: ?>
				<tr><td colspan="4"><em>No sent emails</em></td></tr>
			<?php endif; ?>
		</table>
	</div>
</div>
