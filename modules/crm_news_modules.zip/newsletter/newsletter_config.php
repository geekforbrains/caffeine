<?php if(!defined('CAFFEINE_ROOT')) die ('No direct script access allowed.');
/**
 * =============================================================================
 * Newsletter Configurations
 * =============================================================================
 */
define('NEWSLETTER_FROM_NAME', 'Input Creative');
define('NEWSLETTER_FROM_EMAIL', 'noreply@inputcreative.com');
define('NEWSLETTER_QUEUE_THROTTLE', 100); // How many to people to send to, per cron
define('NEWSLETTER_SEND_THROTTLE', 0); // How many seconds to wait between each email send

/**
 * =============================================================================
 * Newsletter Constants
 * =============================================================================
 */
define('NEWSLETTER_TYPE_TEMPLATE', 'newsletter_template');
define('NEWSLETTER_TYPE_TEMPLATE_FIELD', 'newsletter_template_field');
define('NEWSLETTER_TYPE_EMAIL', 'newsletter_email');
define('NEWSLETTER_TYPE_CACHE', 'newsletter_cache');
define('NEWSLETTER_TYPE_CACHE_LINK', 'newsletter_cache_link');

define('NEWSLETTER_TEMPLATE_FILE', 'template.html');
