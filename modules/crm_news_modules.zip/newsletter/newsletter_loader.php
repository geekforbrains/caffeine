<?php 
class Newsletter_Loader {

	public static function load($cache_cid, $person_cid)
	{
		// Get email cache and subject for person
		$email = Newsletter_Model_Emails::get_cache_by_cid($cache_cid);

		// Convert cache links to trackers for person
		$email['html'] = self::_convert_links($email['html'], $cache_cid, $person_cid);

		// Insert tracker image for person
		$email['html'] = self::_insert_tracker_image($email['html'], $cache_cid, $person_cid);

		// Convert unsubscribe_url
		$email['html'] = self::_insert_unsubscribe_url($email['html'], $cache_cid, $person_cid);

		// Convert webview_url
		$email['html'] = self::_insert_webview_url($email['html'], $cache_cid, $person_cid);

		// Convert template images to media urls
		//$email['html'] = self::_convert_template_images($email['html'], $cache_cid);

		// Convert field images to media urls
		//$email['html'] = self::_convert_field_images($email['html'], $cache_cid);

		return $email['html'];
	}

	private static function _convert_links($html, $cache_cid, $person_cid)
	{
		if(preg_match_all('/a[\s]+href=["\']([^"\']+)["\']/', $html, $matches, PREG_SET_ORDER))
		{
			foreach($matches as $match)
			{
				$url = $match[1];

				// Ignore unsubscribe and webview, those are custom links 
				if($url != '{unsubscribe_url}' && $url != '{webview_url}')
				{
					$link_cid = Newsletter_Model_Emails::get_link_cid($cache_cid, $url);
					$html = str_replace($url, Router::full_url('newsletter/link/%d/%d/%d',
						$cache_cid, $person_cid, $link_cid), $html);
				}
			}
		}

		return $html;
	}

	private static function _insert_tracker_image($html, $cache_cid, $person_cid)
	{
		$url = Router::full_url('newsletter/image/%d/%d', $cache_cid, $person_cid);
		$image = '<img src="'.$url.'" />';
		return str_replace('{tracker_img}', $image, $html);
	}

	private static function _insert_unsubscribe_url($html, $cache_cid, $person_cid)
	{
		$url = Router::full_url('newsletter/unsubscribe/%d/%d', $cache_cid, $person_cid);
		return str_replace('{unsubscribe_url}', $url, $html);
	}

	private static function _insert_webview_url($html, $cache_cid, $person_cid)
	{
		$url = Router::full_url('newsletter/view/%d/%d', $cache_cid, $person_cid);
		return str_replace('{webview_url}', $url, $html);
	}

	/*
	private static function _convert_template_images($html, $cache_cid)
	{
		$images = Newsletter_Model_Emails::get_template_files_by_cache_cid($cache_cid);

		foreach($images as $image)
		{
			$media = Media::get($image['media_cid']);
			$media_url = Router::full_url('media/image/%d', $media['cid']);
			$html = str_replace($media['name'], $media_url, $html);
		}

		return $html;
	}

	private static function _convert_field_images($html, $cache_cid)
	{
		$images = Newsletter_Model_Emails::get_field_images_by_cache_cid($cache_cid);

		foreach($images as $image)
		{
			$media = Media::get($image['value']);
			$media_url = Router::full_url('media/image/%d', $media['cid']);
			$html = str_replace('image' . $image['value'], $media_url, $html);
		}

		return $html;
	}
	*/

}
