<?php 
class Newsletter_Model_Emails {

	public static function get_all($published = 1)
	{
		Database::query('
			SELECT
				ne.*,
				c.created,
				c.updated
			FROM {newsletter_emails} ne
				JOIN {content} c ON c.id = ne.cid
			WHERE ne.published = %s
				AND c.site_cid = %s
			',
			$published,
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function get_scheduled()
	{
		Database::query('
			SELECT
				nc.*,
				ns.*,
				c.created,
				c.updated
			FROM {newsletter_cache} nc
				JOIN {content} c ON c.id = nc.cid
				JOIN {newsletter_sent} ns ON ns.cache_cid = nc.cid
			WHERE c.site_cid = %s
				AND ns.scheduled_for > 0
				AND ns.finished_at = 0
			ORDER BY
				ns.scheduled_for ASC
			',
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function get_sent()
	{
		Database::query('
			SELECT
				nc.*,
				ns.*,
				c.created,
				c.updated
			FROM {newsletter_cache} nc
				JOIN {content} c ON c.id = nc.cid
				JOIN {newsletter_sent} ns ON ns.cache_cid = nc.cid
			WHERE c.site_cid = %s
				AND ns.finished_at > 0
			ORDER BY
				ns.scheduled_for DESC
			',
			User::current_site()
		);

		return Database::fetch_all();
	}

	public static function get_by_cid($cid)
	{
		Database::query('
			SELECT
				ne.*,
				nt.html,
				c.created,
				c.updated
			FROM {newsletter_emails} ne
				JOIN {content} c ON c.id = ne.cid
				JOIN {newsletter_templates} nt ON nt.cid = ne.template_cid
			WHERE ne.cid = %s
				AND c.site_cid = %s
			',
			$cid,
			User::current_site()
		);

		if(Database::num_rows())
		{
			$email = Database::fetch_array();
			$email['fields'] = self::get_fields($cid);
			return $email;
		}

		return false;
	}

	public static function get_sent_by_cid($cache_cid)
	{
		Database::query('
			SELECT
				nc.*,
				ns.*,
				c.created,
				c.updated
			FROM {newsletter_cache} nc
				JOIN {content} c ON c.id = nc.cid
				JOIN {newsletter_sent} ns ON ns.cache_cid = nc.cid
			WHERE nc.cid = %s
				AND c.site_cid = %s
			',
			$cache_cid,
			User::current_site()
		);

		return Database::fetch_array();
	}

	public static function get_fields($email_cid)
	{
		Database::query('
			SELECT
				ntf.*,
				nef.value
			FROM {newsletter_emails} ne 
				LEFT JOIN {newsletter_template_fields} ntf ON ntf.template_cid = ne.template_cid
				LEFT JOIN {newsletter_email_fields} nef ON nef.template_field_cid = ntf.cid
			WHERE
				ne.cid = %s
			',
			$email_cid
		);

		$rows = Database::fetch_all();

		foreach($rows as &$row)
		{
			if(strlen($row['options']))
				$row['options'] = unserialize($row['options']);

			if(strlen($row['fields']))
				$row['fields'] = unserialize($row['fields']);
		}

		return $rows;
	}

	public static function get_field($email_cid, $field_cid)
	{
		Database::query('
			SELECT * FROM {newsletter_email_fields} 
			WHERE email_cid = %s
				AND template_field_cid = %s
			',
			$email_cid,
			$field_cid
		);

			$row['options'] = unserialize($row['options']);
		if(Database::num_rows() > 0)
			return Database::fetch_array();
		return false;
	}

	public static function get_field_count($email_cid, $field_cid)
	{
		Database::query('
			SELECT COUNT(*) AS count FROM {newsletter_email_fields} 
			WHERE email_cid = %s AND template_field_cid = %s
			',
			$email_cid,
			$field_cid
		);

		return intval(Database::fetch_single('count'));
	}

	public static function clear_field($email_cid, $field_cid)
	{
		Database::update('newsletter_email_fields',
			array('value' => ''),
			array(
				'email_cid' => $email_cid,
				'template_field_cid' => $field_cid
			)
		);
		
		// If a field is cleared for an email, also set the email as draft
		Database::update('newsletter_emails',
			array('published' => 0),
			array('cid' => $email_cid)
		);
	}

	public static function create($template_cid, $subject)
	{
		$cid = Content::create(NEWSLETTER_TYPE_EMAIL);
		Database::insert('newsletter_emails', array(
			'cid' => $cid,
			'template_cid' => $template_cid,
			'subject' => $subject
		));

		/*
		$fields = Newsletter_Model_Templates::get_fields($template_cid);
		foreach($fields as $field)
		{
			Database::insert('newsletter_email_fields', array(
				'email_cid' => $cid,
				'template_field_cid' => $field['cid']
			));
		}
		*/

		return $cid;
	}

	public static function delete($cid)
	{
		Content::delete($cid);
		Database::delete('newsletter_email_fields', array('email_cid' => $cid));
		return Database::delete('newsletter_emails', array('cid' => $cid));
	}

	public static function update($email_cid, $subject, $body, $published)
	{
		Content::update($email_cid);
		return Database::update('newsletter_emails',
			array(
				'subject' => $subject,
				'body' => $body,
				'published' => $published
			),
			array('cid' => $email_cid)
		);
	}

	public static function insert_field($email_cid, $field_cid, $value)
	{
		Database::insert('newsletter_email_fields', array(
			'email_cid' => $email_cid,
			'template_field_cid' => $field_cid,
			'value' => $value,
			'value_hash' => md5($value)
		));

		return true;
	}

	public static function update_field($email_cid, $field_cid, $value)
	{
		Database::update('newsletter_email_fields',
			array(
				'value' => $value,
				'value_hash' => md5($value)
			),
			array(
				'email_cid' => $email_cid,
				'template_field_cid' => $field_cid
			)
		);

		return true;
	}

	public static function create_cache($email_cid, $subject, $cache)
	{
		$cid = Content::create(NEWSLETTER_TYPE_CACHE);

		Database::insert('newsletter_cache', array(
			'cid' => $cid,
			'email_cid' => $email_cid,
			'subject' => $subject,
			'html' => $cache
		));

		return $cid;
	}

	public static function schedule_email($cache_cid, $timestamp, $total_sent)
	{
		return Database::insert('newsletter_sent', array(
			'cache_cid' => $cache_cid,
			'scheduled_for' => $timestamp,
			'total_sent' => $total_sent
		));
	}

	public static function add_to_queue($cache_cid, $people)
	{
		$values = '';
		foreach($people as $person)
			$values .= sprintf('(%s, %s),', $cache_cid, $person['cid']);
		$values = rtrim($values, ',');

		Database::query('INSERT INTO {newsletter_queue} (cache_cid, person_cid) VALUES ' .$values);
	}

	public static function get_from_queue($limit)
	{
		Database::query('
			SELECT 	
				nq.* 
			FROM {newsletter_queue} nq
				JOIN {newsletter_sent} ns ON ns.cache_cid = nq.cache_cid
			WHERE
				ns.scheduled_for <= %s
			LIMIT ' . $limit,
			time()
		);

		return Database::fetch_all();
	}

	public static function delete_from_queue($cache_cid, $person_cid)
	{
		Database::delete('newsletter_queue', array(
			'cache_cid' => $cache_cid,
			'person_cid' => $person_cid
		));
	}

	public static function update_finished($cache_cid)
	{
		Database::update('newsletter_sent',
			array('finished_at' => time()),
			array('cache_cid' => $cache_cid)
		);
	}

	public static function get_cache_by_cid($cache_cid)
	{
		Database::query('SELECT * FROM {newsletter_cache} WHERE cid = %s',
			$cache_cid);

		if(Database::num_rows() > 0)
			return Database::fetch_array();
		return false;
	}

	public static function get_link_cid($cache_cid, $url)
	{
		Database::query('
			SELECT cid FROM {newsletter_cache_links} 
			WHERE cache_cid = %s AND url_hash = MD5(%s)
			',
			$cache_cid,
			$url
		);

		if(Database::num_rows() > 0)
			return Database::fetch_single('cid');
		else
		{
			$cid = Content::create(NEWSLETTER_TYPE_CACHE_LINK);

			Database::insert('newsletter_cache_links', array(
				'cid' => $cid,
				'cache_cid' => $cache_cid,
				'url' => $url,
				'url_hash' => md5($url)
			));

			return $cid;
		}
	}

	/*
	public static function get_template_files_by_cache_cid($cache_cid)
	{
		Database::query('
			SELECT
				ntf.*
			FROM {newsletter_cache} nc
				JOIN {newsletter_emails} ne ON ne.cid = nc.email_cid
				JOIN {newsletter_template_files} ntf ON ntf.template_cid = ne.template_cid
			WHERE
				nc.cid = %s
			',
			$cache_cid
		);

		return Database::fetch_all();
	}
	*/

	public static function get_template_files_by_email_cid($email_cid)
	{
		Database::query('
			SELECT
				ntf.*
			FROM {newsletter_emails} ne
				JOIN {newsletter_template_files} ntf ON ntf.template_cid = ne.template_cid
			WHERE
				ne.cid = %s
			',
			$email_cid
		);

		return Database::fetch_all();
	}

	/*
	public static function get_field_images_by_cache_cid($cache_cid)
	{
		Database::query('
			SELECT
				nef.value
			FROM {newsletter_cache} nc
				JOIN {newsletter_email_fields} nef ON nef.email_cid = nc.email_cid
				JOIN {newsletter_template_fields} ntf ON ntf.cid = nef.template_field_cid
			WHERE ntf.type = %s
				AND nc.cid = %s
			',
			'image',
			$cache_cid
		);

		return Database::fetch_all();
	}
	*/

	public static function get_field_images_by_email_cid($email_cid)
	{
		Database::query('
			SELECT
				nef.value,
				ntf.*
			FROM {newsletter_email_fields} nef
				JOIN {newsletter_template_fields} ntf ON ntf.cid = nef.template_field_cid
			WHERE ntf.type = %s 
				AND nef.email_cid = %s
			',
			'image',
			$email_cid
		);

		return Database::fetch_all();
	}

	public static function get_links_by_cache_cid($cache_cid)
	{
		Database::query('SELECT * FROM {newsletter_cache_links} WHERE cache_cid = %s', $cache_cid);
		$rows = Database::fetch_all();

		foreach($rows as &$row)
		{
			Database::query('
				SELECT COUNT(*) AS clicks 
				FROM {newsletter_track_links} 
				WHERE cache_cid = %s
					AND cache_link_cid = %s
				',
				$cache_cid,
				$row['cid']
			);

			$row['clicks'] = Database::fetch_single('clicks');
		}

		return $rows;
	}

	public static function delete_value($email_cid, $value_hash)
	{
		return Database::delete('newsletter_email_fields', array(
			'email_cid' => $email_cid,
			'value_hash' => $value_hash
		));
	}

	public static function value_exists($email_cid, $value)
	{
		Database::query('
			SELECT * FROM {newsletter_email_fields} 
			WHERE email_cid = %s AND value_hash = %s
			',
			$email_cid,
			md5($value)
		);

		if(Database::num_rows() > 0)
			return true;
		return false;
	}

}
