<?php 
class Newsletter_Sender {

	// Called each cron job
	public static function process()
	{
		// Get next set from queue
		$rows = Newsletter_Model_Emails::get_from_queue(NEWSLETTER_QUEUE_THROTTLE);

		if($rows)
		{
			foreach($rows as $row)
			{
				// If send to person was successful, delete them from queue
				if(self::_send($row['cache_cid'], $row['person_cid']))
				{
					Newsletter_Model_Emails::delete_from_queue($row['cache_cid'], $row['person_cid']);
					Newsletter_Model_Emails::update_finished($row['cache_cid']);
				}

				sleep(NEWSLETTER_SEND_THROTTLE);
			}
		}

		exit();
	}

	private static function _send($email_cache_cid, $person_cid)
	{
		$email = Newsletter_Model_Emails::get_cache_by_cid($email_cache_cid);
		$person = CRM_Model_People::get_by_cid($person_cid);
		$html = Newsletter_Loader::load($email_cache_cid, $person_cid);

		//printf('Sending "%s" to %s', $email['subject'], $person['email']);

		Mailer::to($person['email']);
		Mailer::from(NEWSLETTER_FROM_EMAIL, NEWSLETTER_FROM_NAME);
		Mailer::subject($email['subject']);
		Mailer::body($html, true);

		return Mailer::send();
	}

}
