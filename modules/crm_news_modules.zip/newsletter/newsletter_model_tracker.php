<?php
class Newsletter_Model_Tracker {

	public static function open($cache_cid, $person_cid)
	{
		Database::query('
			SELECT * FROM {newsletter_track_opens}
			WHERE cache_cid = %s
				AND person_cid = %s
			',
			$cache_cid,
			$person_cid
		);

		if(Database::num_rows() <= 0)
		{
			Database::insert('newsletter_track_opens', array(
				'cache_cid' => $cache_cid,
				'person_cid' => $person_cid,
				'opened_at' => time()
			));

			// If new open, track total opens
			Database::query('
				UPDATE {newsletter_sent} SET total_opened = total_opened + 1
				WHERE cache_cid = %s
				',
				$cache_cid
			);
		}
	}

	public static function click($cache_cid, $person_cid, $link_cid)
	{
		Database::query('	
			SELECT * FROM {newsletter_track_links}
			WHERE cache_cid = %s
				AND person_cid = %s
				AND cache_link_cid = %s
			',
			$cache_cid,
			$person_cid,
			$link_cid
		);

		if(Database::num_rows() <= 0)
		{
			Database::insert('newsletter_track_links', array(
				'cache_cid' => $cache_cid,
				'person_cid' => $person_cid,
				'cache_link_cid' => $link_cid,
				'clicked_at' => time()
			));
		}
	}

	public static function get_url($link_cid)
	{
		Database::query('
			SELECT url FROM {newsletter_cache_links}
			WHERE cid = %s
			',
			$link_cid
		);

		if(Database::num_rows() > 0)
			return Database::fetch_single('url');
		return false;
	}

}
