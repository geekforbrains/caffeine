<?php
class Newsletter {

	public static function cron() {
		Newsletter_Sender::process();
	}

	public static function link($cache_cid, $person_cid, $link_cid)
	{
		Newsletter_Model_Tracker::open($cache_cid, $person_cid);
		Newsletter_Model_Tracker::click($cache_cid, $person_cid, $link_cid);
		$url = Newsletter_Model_Tracker::get_url($link_cid);

		if($url)
			Router::redirect($url);
		else
			Router::redirect('/');
	}

	public static function image($cache_cid, $person_cid)
	{
		Newsletter_Model_Tracker::open($cache_cid, $person_cid);

		$im = imagecreatetruecolor(1 ,1);
		imagecolortransparent($im, imagecolorallocate($im, 0, 0, 0));
		header('Content-type: image/png');
		imagepng($im);
		imagedestroy($im);

		exit;
	}

	public static function unsubscribe($cache_cid, $person_cid)
	{
		Newsletter_Model_Tracker::open($cache_cid, $person_cid);	
		die("You have been successfully removed from our mailing list.");
	}

	public static function view($cache_cid, $person_cid)
	{
		Newsletter_Model_Tracker::open($cache_cid, $person_cid);
		$html = Newsletter_Loader::load($cache_cid, $person_cid);
		echo $html;
		exit();
	}

}
