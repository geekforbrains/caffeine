<?php
class Newsletter_Events {

	public static function path_callbacks()
	{
		return array(
			// Cron
			'newsletter/cron' => array(
				'callback' => array('Newsletter', 'cron'),
				'visible' => false,
				'auth' => true
			),

			// Trackers
			'newsletter/link/%d/%d/%d' => array( // email_cid/person_cid/link_cid
				'callback' => array('Newsletter', 'link'),
				'auth' => true
			),
			'newsletter/image/%d/%d' => array( // email_cid/person_cid
				'callback' => array('Newsletter', 'image'),
				'auth' => true
			),
			'newsletter/unsubscribe/%d/%d' => array(
				'callback' => array('Newsletter', 'unsubscribe'),
				'auth' => true
			),
			'newsletter/view/%d/%d' => array(
				'callback' => array('Newsletter', 'view'),
				'auth' => true
			),


			// Admin Emails
			'admin/newsletter' => array(
				'title' => 'Newsletter',
				'alias' => 'admin/newsletter/emails/overview'
			),
			'admin/newsletter/emails' => array(
				'title' => 'Emails',
				'alias' => 'admin/newsletter/emails/overview'
			),
			'admin/newsletter/emails/overview' => array(
				'title' => 'Overview',
				'callback' => array('Newsletter_Admin_Emails', 'overview'),
				'auth' => 'overview emails'
			),
			'admin/newsletter/emails/manage' => array(
				'title' => 'Manage Emails',
				'callback' => array('Newsletter_Admin_Emails', 'manage'),
				'auth' => 'manage emails'
			),
			'admin/newsletter/emails/create' => array(
				'title' => 'Create Email',
				'callback' => array('Newsletter_Admin_Emails', 'create'),
				'auth' => 'create emails'
			),
			'admin/newsletter/emails/details/%d' => array(
				'callback' => array('Newsletter_Admin_Emails', 'details'),
				'auth' => 'view email details'
			),
			'admin/newsletter/emails/edit/%d' => array(
				'callback' => array('Newsletter_Admin_Emails', 'edit'),
				'auth' => 'edit emails'
			),
			'admin/newsletter/emails/edit/%d/delete-image/%d' => array(
				'callback' => array('Newsletter_Admin_Emails', 'delete_image'),
				'auth' => 'delete email images'
			),
			'admin/newsletter/emails/edit/%d/delete-value/%' => array(
				'callback' => array('Newsletter_Admin_Emails', 'delete_value'),
				'auth' => 'delete module values'
			),
			'admin/newsletter/emails/delete/%d' => array(
				'callback' => array('Newsletter_Admin_Emails', 'delete'),
				'auth' => 'delete emails'
			),
			'admin/newsletter/emails/send' => array(
				'title' => 'Send Email',
				'callback' => array('Newsletter_Admin_Emails', 'send'),
				'auth' => 'send emails'
			),
			
			// Admin Templates
			'admin/newsletter/templates' => array(
				'title' => 'Templates',
				'alias' => 'admin/newsletter/templates/manage'
			),
			'admin/newsletter/templates/manage' => array(
				'title' => 'Manage Templates',
				'callback' => array('Newsletter_Admin_Templates', 'manage'),
				'auth' => 'manage templates'
			),
			'admin/newsletter/templates/create' => array(
				'title' => 'Create Template',
				'callback' => array('Newsletter_Admin_Templates', 'create'),
				'auth' => 'create templates'
			),
			'admin/newsletter/templates/edit/%d' => array(
				'callback' => array('Newsletter_Admin_Templates', 'edit'),
				'auth' => 'edit templates'
			),
			'admin/newsletter/templates/delete/%d' => array(
				'callback' => array('Newsletter_Admin_Templates', 'delete'),
				'auth' => 'delete templates'
			)
		);
	}

	public static function database_install()
	{
		return array(
			'newsletter_templates' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'name' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'html' => array(
						'type' => 'text',
						'size' => 'normal',
						'not null' => true
					)
				),

				'indexes' => array(
					'name' => array('name')
				),

				'primary key' => array('cid')
			),

			'newsletter_template_fields' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'template_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'tag' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'type' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'field' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'name' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'options' => array(
						'type' => 'text',
						'size' => 'normal',
						'not null' => true
					),
					'fields' => array(
						'type' => 'text',
						'size' => 'normal',
						'not null' => true
					)
				),

				'indexes' => array(
					'template_cid' => array('template_cid'),
					'tag' => array('tag'),
					'type' => array('type')
				),

				'primary key' => array('cid')
			),

			'newsletter_template_files' => array(
				'fields' => array(
					'template_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'media_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					)
				),

				'indexes' => array(
					'template_cid' => array('template_cid'),
					'media_cid' => array('media_cid')
				)

			),

			'newsletter_emails' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'template_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'subject' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'body' => array(
						'type' => 'text',
						'size' => 'normal',
						'not null' => true
					),
					'published' => array(
						'type' => 'int',
						'size' => 'tiny',
						'not null' => true
					)
				),

				'indexes' => array(
					'template_cid' => array('template_cid')
				),

				'primary key' => array('cid')
			),

			'newsletter_email_fields' => array(
				'fields' => array(
					'email_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'template_field_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'value' => array(
						'type' => 'text',
						'size' => 'normal',
						'not null' => true
					),
					'value_hash' => array(
						'type' => 'varchar',
						'length' => 32,
						'not null' => true
					)
				),

				'indexes' => array(
					'email_cid' => array('email_cid'),
					'template_field_cid' => array('template_field_cid')
				)
			),

			'newsletter_cache' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'email_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'subject' => array(
						'type' => 'varchar',
						'length' => 255,
						'not null' => true
					),
					'html' => array(
						'type' => 'text',
						'size' => 'normal',
						'not null' => true
					)
				),

				'indexes' => array(
					'email_cid' => array('email_cid')
				),

				'primary key' => array('cid')
			),

			'newsletter_cache_links' => array(
				'fields' => array(
					'cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'cache_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'url' => array(
						'type' => 'text',
						'size' => 'normal',
						'not null' => true
					),
					'url_hash' => array(
						'type' => 'varchar',
						'length' => 32,
						'not null' => true
					)
				),

				'indexes' => array(
					'cache_cid' => array('cache_cid'),
					'url_hash' => array('url_hash')
				),

				'primary key' => array('cid')
			),


			'newsletter_sent' => array(
				'fields' => array(
					'cache_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'scheduled_for' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'finished_at' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'total_sent' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'total_opened' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					)
				),

				'indexes' => array(
					'cache_cid' => array('cache_cid'),
					'scheduled_for' => array('scheduled_for'),
					'finished_at' => array('finished_at')
				)
			),

			'newsletter_queue' => array(
				'fields' => array(
					'cache_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'person_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					)
				),

				'indexes' => array(
					'cache_cid' => array('cache_cid'),
					'person_cid' => array('person_cid')
				)
			),

			'newsletter_track_opens' => array(
				'fields' => array(
					'cache_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'person_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'opened_at' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					)
				),

				'indexes' => array(
					'cache_cid' => array('cache_cid'),
					'person_cid' => array('person_cid')
				)
			),

			'newsletter_track_links' => array(
				'fields' => array(
					'cache_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'cache_link_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'person_cid' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					),
					'clicked_at' => array(
						'type' => 'int',
						'size' => 'big',
						'unsigned' => true,
						'not null' => true
					)
				),

				'indexes' => array(
					'cache_cid' => array('cache_cid'),
					'cache_link_cid' => array('cache_link_cid'),
					'person_cid' => array('person_cid')
				)
			)
		);
	}

}
